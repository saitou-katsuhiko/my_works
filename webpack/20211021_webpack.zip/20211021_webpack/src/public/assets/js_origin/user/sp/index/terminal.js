import messageAlert from "../modules/messageAlert.js"
messageAlert('indexです！！！');