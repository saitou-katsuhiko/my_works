export default function messageAlert(m){
    alert( 'webpackTestの' + m);
}